# GodotGPT
Experimental GPT + Godot 4 integration

Creation Video: https://www.youtube.com/watch?v=87cOYBerFMo

This is just for testing purposes! It's not intended to be used in production environment. The code is buggy and made in a couple of hours, but it's free. Enjoy.

## Installation
1. Copy the addon folder to your project's folder.
2. Activate the plugin
3. Create a config key under "application/config/openai_api" and copy your GPT API secret Key there.
4. Enjoy
