
//Licensing & About
Thanks for supporting the VIEWPOINT Sideview Fantasy Free Trees assets by LUNARSIGNALS. VIEWPOINT is a new series of pixel art I am creating. Be on the lookout for more packs under this name.

VIEWPOINT Sideview Fantasy Free Trees is licensed under the Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0). This license allows adaptations of your work to be shared under the same license, and allows your work to be used commercially, as long as it's attributed to LUNARSIGNALS. This is a Free Culture License. https://creativecommons.org/licenses/by-sa/4.0/

LUNARSIGNALS is a one person game development studio making pixel art and independent games. Follow @LUNARSIGNALS on twitter. And find my other products on https://lunarsignals.itch.io/