﻿using System.Collections;
using UnityEngine;
using System.Collections;


public class DestroyObject : MonoBehaviour {
	public void DestroyEvent() {
		Destroy (gameObject); 
	}
}